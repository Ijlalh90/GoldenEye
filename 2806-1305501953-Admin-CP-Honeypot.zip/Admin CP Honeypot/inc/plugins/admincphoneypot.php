<?php
/*************************************************************************
* MyBB Admin CP Honeypot
* Copyright 2011 MyBBWebHost, all rights reserved.
* You may not distribute this plugin for any reason.
**************************************************************************
* The use of this plugin does not guarantee that your forum
* will not be hacked.  This is only one of many safety measures
* that can be used to reduce (not eliminate) chances.
**************************************************************************
* This plugin is provided "as-is" and "as-available". MyBBWebHost and
* any associated parties will not be liable for any damage that results
* from use of this plugin.
**************************************************************************
* Need support? Visit the support thread: http://community.mybb.com/thread-94406.html
**************************************************************************
* Need secure hosting?  Try http://www.mybbwebhost.com
**************************************************************************/

if(!defined("IN_MYBB")) {
	header('Status: 404 Not Found'); 
	echo "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /inc/plugins/admincphoneypot.php was not found on this server.</p>
</body></html>
";
	exit;
}

// Plugin Information
function admincphoneypot_info()
{
    return array(
        "name"        => "Admin CP Honeypot",
        "description" => "Creates a fake Admin CP login page, where visitors attempting to login will get a 'Wrong username/password' error and you will be notified of their failed login attempt (and details).",
        "website"     => "http://www.mybbwebhost.com",
        "author"      => "MyBBWebHost",
        "authorsite"  => "http://www.mybbwebhost.com",
        "guid"  => "f89e20434883b70f53420a46f4ff68cc",
        "version"     => "1.0",
	"compatibility" => "*",
        );
}

function admincphoneypot_is_installed()
{
	global $db;

if ($db->num_rows($db->simple_select("settings","name","name='fa_subject'")) >= 1)	
{
		return true;
	}

	return false;
}

// Install and Activate
function admincphoneypot_activate() {

global $db;

    $fa_group = array(
        "gid" => "NULL",
        "name" => "admincphoneypot",
        "title" => "Admin CP Honeypot Settings",
        "description" => "Change the settings for the emails that will be sent out by the Admin CP Honeypot.",
        "disporder" => "35",
        "isdefault" => "no",
        );
    $db->insert_query("settinggroups", $fa_group);
    $gid = $db->insert_id();
    
    $fa_1 = array(
        "sid" => "NULL",
        "name" => "fa_subject",
        "title" => "Email Subject",
        "description" => "This is the subject of the email.",
        "optionscode" => "text",
        "value" => "Admin CP Honeypot Login Attempt",
        "disporder" => "1",
        "gid" => intval($gid),
        );
    $db->insert_query("settings", $fa_1);
  
    $fa_2 = array(
        "sid" => "NULL",
        "name" => "fa_toemail",
        "title" => "To Email",
        "description" => "All emails will be sent here.",
        "optionscode" => "text",
        "value" => "youremail@example.com",
        "disporder" => "2",
        "gid" => intval($gid),
        );
    $db->insert_query("settings", $fa_2);

    $fa_3 = array(
        "sid" => "NULL",
        "name" => "fa_fromemail",
        "title" => "From Email",
        "description" => "All emails will be sent from here.  You do not have to fill in this field, but if you do, make sure the email is not being picked up as spam.",
        "optionscode" => "text",
        "value" => "",
        "disporder" => "3",
        "gid" => intval($gid),
        );
    $db->insert_query("settings", $fa_3);

rebuild_settings();

}

// Deactivate and Uninstall
function admincphoneypot_deactivate() {

global $db, $mybb;
    require "../inc/adminfunctions_templates.php";
    $query = $db->query("SELECT gid FROM ".TABLE_PREFIX."settinggroups WHERE name='admincphoneypot'");
    $g = $db->fetch_array($query);
    $db->query("DELETE FROM ".TABLE_PREFIX."settinggroups WHERE gid='".$g['gid']."'");
    $db->query("DELETE FROM ".TABLE_PREFIX."settings WHERE gid='".$g['gid']."'");

rebuild_settings();

global $db;

}
?>