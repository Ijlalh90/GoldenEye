MyBB Admin CP Honeypot
Copyright 2011 MyBBWebHost, all rights reserved.
You may not distribute this plugin for any reason.

--------------------------

The use of this plugin does not guarantee that your forum
will not be hacked.  This is only one of many safety measures
that can be used to reduce (not eliminate) chances.

--------------------------

This plugin is provided "as-is" and "as-available". MyBBWebHost and
any associated parties will not be liable for any damage that results
from use of this plugin.

--------------------------

Need support? Visit the support thread: http://community.mybb.com/thread-94406.html

--------------------------

Admin CP Honeypot creates a fake Admin Control Panel login page, where visitors
attempting to login will get an eternal 'Wrong username/password' error and you
will be emailed their attempted login details.

In addition, attempting to access /inc/plugins/admincphoneypot.php will give a 404 error.

--------------------------

Instructions:

1) Rename your /admin/ directory (This is a MUST!) - http://community.mybboard.net/thread-44977.html

2) Upload the new /admin/ directory and the plugin to your inc/plugins/ folder.

3) Install and Activate the plugin via your Admin CP.

4) Go to Configuration --> Admin CP Honeypot Settings and edit the settings as you wish.

Note: The plugin will work perfectly fine even if you don't "install" it.  The only difference
is that if you wish to recieve notification emails, then you will need to configure the settings.

--------------------------

WARNING: If you configure your email address, you will recieve a notification email with details
EVERY TIME they click the submit button!  To avoid inbox flooding, it is recommended that
you either create an email account for just this purpose or get Gmail, where similar
emails are threaded together.

--------------------------

License:

You may:

- Install this plugin on your own installation of MyBB.
- Edit this plugin for your own personal needs.
- Remove visible page copyright (setting in Admin CP).

You may not:

- Distribute this plugin.
- Edit/modify this plugin and then distribute it.
- Remove in-file copyrights.
- Claim this plugin as your own work.

Plugin is provided as-is.  The plugin author and MyBBWebHost is not responsible for any damages
done to your board through use (indirect or direct) of this plugin.  Use at your own risk.

--------------------------

Need web hosting?  www.MyBBWebHost.com offers enterprise-level hosting with MyBB optimized
and compatible servers, as well as a MyBB-savvy staff that is ready to help you out!


