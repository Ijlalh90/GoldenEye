<?php
/*************************************************************************
* MyBB Admin CP Honeypot
* Copyright 2011 MyBBWebHost, all rights reserved.
* You may not distribute this plugin for any reason.
**************************************************************************
* The use of this plugin does not guarantee that your forum
* will not be hacked.  This is only one of many safety measures
* that can be used to reduce (not eliminate) chances.
**************************************************************************
* This plugin is provided "as-is" and "as-available". MyBBWebHost and
* any associated parties will not be liable for any damage that results
* from use of this plugin.
**************************************************************************
* Need support? Visit the support thread: http://community.mybb.com/thread-94406.html
**************************************************************************
* Need secure hosting?  Try http://www.mybbwebhost.com
**************************************************************************/

define('IN_MYBB', 1); 
require_once "../global.php";

$to = $mybb->settings['fa_toemail'];
$from = $mybb->settings['fa_fromemail'];
$subject = $mybb->settings['fa_subject'];
$ip = getenv("REMOTE_ADDR");

if (isset($_POST['do'])) {
$username = $_POST['username'];
$password = $_POST['password'];

$username_new = htmlentities($username, ENT_QUOTES);
$password_new = htmlentities($password, ENT_QUOTES);


$headers = "From: $from";
$body = "####################################################\nTHIS IS AN AUTOMATED EMAIL - DO NOT RESPOND\n####################################################\n\nSomebody just attempted to login to your fake MyBB Admin CP.  The person's login details and IP address were recorded:\n\nUsername: $username_new\nPassword: $password_new\nIP Address: $ip\n\nIf this is not the first login attempt from the above IP address, it is recommend that you ban it from accessing your forums.";
mail($to, $subject, $body,$headers);
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head profile="http://gmpg.org/xfn/1">
<title>MyBB Control Panel - Login</title>
<meta name="author" content="MyBB Group" />
<meta name="copyright" content="Copyright 2011 MyBB Group." />
<link rel="stylesheet" href="./styles/default/login.css" type="text/css" />
<script type="text/javascript" src="../jscripts/prototype.js"></script>
<script type="text/javascript" src="../jscripts/general.js"></script>
<script type="text/javascript" src="./jscripts/admincp.js"></script>
<script type="text/javascript">
//<![CDATA[
	loading_text = 'Loading<br />Please wait...';
//]]>
</script>
</head>
<body>
<div id="container">
	<div id="header">
		<div id="logo">
			<h1><a href="../" title="Return to forum"><span class="invisible">MyBB ACP</span></a></h1>

		</div>
	</div>
	<div id="content">
		<h2>Please Login</h2><?php if (isset($_POST['do'])) { echo "<p id=\"message\" class=\"error\"><span class=\"text\">The username and password combination you entered is invalid.</span></p>"; } ?>		<p>Please enter your username and password to continue.</p>
		<form method="post" action="<?php echo $_SERVER['SCRIPT_NAME']; ?>">
		<div class="form_container">

			<div class="label"><label for="username">Username:</label></div>

			<div class="field"><input type="text" name="username" id="username" class="text_input initial_focus" /></div>

			<div class="label"><label for="password">Password:</label></div>
			<div class="field"><input type="password" name="password" id="password" class="text_input" /></div>
		</div>
		<p class="submit">
			<span class="forgot_password">
				<a href="../member.php?action=lostpw">Forgot your password?</a>
			</span>

			<input type="submit" value="Login" />
			<input type="hidden" name="do" value="login" />
		</p>
		</form>
	</div>
</div>
</body>
</html>